/*___Generated_by_IDEA___*/

/** Automatically generated file. DO NOT MODIFY */
package dk.dorland.MiCiW;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}