package dk.dorland.MiCiW;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;

public class DesktopStarter {
    public static void main(String[] args) {
        LwjglApplicationConfiguration cfg = new LwjglApplicationConfiguration();
        cfg.title = "MiCiW";
        cfg.useGL20 = true;
        cfg.width = MiCiWGame.SCREEN_WIDTH;
        cfg.height = MiCiWGame.SCREEN_HEIGHT;
        cfg.resizable = false;
        new LwjglApplication(new MiCiWGame(), cfg);
    }
}