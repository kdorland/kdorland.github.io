package dk.dorland.MiCiW.View;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import dk.dorland.MiCiW.Assets;
import dk.dorland.MiCiW.Colors;
import dk.dorland.MiCiW.GameScreen;
import dk.dorland.MiCiW.MiCiWGame;
import dk.dorland.MiCiW.Model.CircleTower;

public class HUD {
    private static final String TAG = "HUD";

    public enum Buttons {HARVESTER, CANNON, UPGRADE, MUTE_SOUND}

    public static final float HUD_WIDTH = 230f;
    public static final float MARGIN = 10f;
    public static final float PANEL_HEIGHT = 50f;

    private static final String ENERGY = "Energy";
    private static final String SCORE = "Score";
    private static final String BUILD = "Build";
    private static final String SELECTED = "Selected tower:";
    private static final String UPGRADE = "Upgrade tower:";
    private static final String HARVESTER = "Harvester";
    private static final String CANNON = "Cannon";

    private Rectangle hudArea = new Rectangle();
    private GameScreen gameScreen;

    // UI coordinates
    private float panelY1 = MiCiWGame.SCREEN_HEIGHT - MARGIN - 80f;
    private float panelY2 = panelY1 - MARGIN - PANEL_HEIGHT;
    private float buildAreaY = 70f;
    private float selectedAreaY = panelY2 - MARGIN * 3 - buildAreaY;
    private float upgradeAreaY = selectedAreaY - 180f;
    private float upgradeButtonY = upgradeAreaY - 80f;
    private float textHeight = Assets.font.getWrappedBounds(BUILD, HUD_WIDTH).height;

    // UI elements
    private Rectangle buttonHarvester;
    private Rectangle buttonCannon;
    private Rectangle buttonUpgrade;
    private Rectangle buttonMuteSound;

    public HUD(GameScreen screen) {
        this.gameScreen = screen;

        hudArea.width = HUD_WIDTH;
        hudArea.height = MiCiWGame.SCREEN_HEIGHT;
        hudArea.y = 0;
        hudArea.x = MiCiWGame.SCREEN_WIDTH - hudArea.width;

        buttonHarvester = new Rectangle(getArea().x + MARGIN, panelY1 - buildAreaY, getArea().width - MARGIN * 2, PANEL_HEIGHT);
        buttonCannon = new Rectangle(getArea().x + MARGIN, panelY2 - buildAreaY, getArea().width - MARGIN * 2, PANEL_HEIGHT);
        buttonUpgrade = new Rectangle(getArea().x + MARGIN, upgradeButtonY, getArea().width - MARGIN * 2, PANEL_HEIGHT);
        buttonMuteSound = new Rectangle(getArea().x + MARGIN, MARGIN, getArea().width - MARGIN * 2, PANEL_HEIGHT * 0.5f);
    }

    public Rectangle getArea() {
        return hudArea;
    }

    public void render(ShapeRenderer shapeRenderer) {
        // Draw HUD background
        shapeRenderer.setColor(Colors.HUD_BACKGROUND.r, Colors.HUD_BACKGROUND.g, Colors.HUD_BACKGROUND.b, 0.85f);
        shapeRenderer.rect(getArea().x, getArea().y, getArea().width, getArea().height);
        shapeRenderer.setColor(Colors.BLACK.r, Colors.BLACK.g, Colors.BLACK.b, 0.15f);

        // Draw buttons
        shapeRenderer.rect(buttonHarvester.x, buttonHarvester.y, buttonHarvester.width, buttonHarvester.height);
        shapeRenderer.rect(buttonCannon.x, buttonCannon.y, buttonCannon.width, buttonCannon.height);
        shapeRenderer.rect(buttonMuteSound.x, buttonMuteSound.y, buttonMuteSound.width, buttonMuteSound.height);

        // Draw upgrade button
        CircleTower tower = gameScreen.getSelectedTower();
        if (tower != null && tower.getType() == CircleTower.Type.CANNON){
            shapeRenderer.rect(buttonUpgrade.x, buttonUpgrade.y, buttonUpgrade.width, buttonUpgrade.height);
        }

        // Draw selected tower
        if (tower != null) {
            float radius = 40;
            if (tower.getType() == CircleTower.Type.CANNON) {
                shapeRenderer.setColor(Colors.RED);
            } else {
                shapeRenderer.setColor(Colors.BLUE);
            }
            shapeRenderer.circle(
                    getArea().x + HUD.HUD_WIDTH * 0.5f - radius * 0.10f,
                    selectedAreaY - textHeight - radius * 1 - MARGIN*4,
                    radius);
        }
    }

    public void render(SpriteBatch spriteBatch) {
        float x = getArea().x + MARGIN;
        float y = getArea().y + MiCiWGame.SCREEN_HEIGHT - MARGIN;
        float smallLineHeight = Assets.fontSmall.getLineHeight();
        float lineHeight = Assets.font.getLineHeight();

        // Top area
        Assets.font.draw(spriteBatch, ENERGY + ": "+gameScreen.getGameState().energy(), x, y);
        Assets.font.draw(spriteBatch, SCORE + ": "+gameScreen.getGameState().getScore(),
                x, y - smallLineHeight*2.2f);

        // Build area
        String costCannon = " ("+CircleTower.CANNON_BUILD_COST +")";
        String costEnergy = " ("+CircleTower.ENERGY_BUILD_COST +")";

        Assets.font.draw(spriteBatch, BUILD, x, y - buildAreaY);
        Assets.font.draw(spriteBatch, HARVESTER + costEnergy, x + 5f, panelY1 - MARGIN * 3f);
        Assets.font.draw(spriteBatch, CANNON + costCannon, x + 5f, panelY2 - MARGIN * 3f);


        // Select area
        CircleTower tower = gameScreen.getSelectedTower();
        if (tower != null){
            Assets.font.draw(spriteBatch, SELECTED, x, selectedAreaY);
            if (tower.getType() == CircleTower.Type.CANNON) {
                Assets.font.draw(spriteBatch, "Upgrade level: "+tower.upgradeLevel(), x, selectedAreaY - lineHeight);
            }
        }

        // Upgrade area
        if (tower != null && tower.getType() == CircleTower.Type.CANNON) {
            String text = "Buy upgrade ("+tower.upgradeCost()+")";
            if (tower.upgradeLevel() == CircleTower.MAX_LEVEL) {
                text = "(none)";
            }
            Assets.font.draw(spriteBatch, UPGRADE, x, upgradeAreaY);
            Assets.font.draw(spriteBatch, text, x + 5f, upgradeButtonY + lineHeight*1.75f);
        }

        // Mute sound
        String mute = "Mute sound";
        if (Assets.volume == 0.0f) {
            mute = "Unmute sound";
        }
        Assets.fontSmall.draw(spriteBatch, mute, x + MARGIN, smallLineHeight * 2.5f);

    }

    public Buttons handleInput(float inputX, float inputY) {
        if (buttonHarvester.contains(getArea().x + inputX, getArea().y + inputY)) {
            Gdx.app.log(TAG, "Handled by buttonHarvester!");
            return Buttons.HARVESTER;
        } else if (buttonCannon.contains(getArea().x + inputX, getArea().y + inputY)) {
            Gdx.app.log(TAG, "Handled by buttonCannon!");
            return Buttons.CANNON;
        } else if (buttonUpgrade.contains(getArea().x + inputX, getArea().y + inputY)) {
            Gdx.app.log(TAG, "Handled by buttonUpgrade!");
            return Buttons.UPGRADE;
        } else if (buttonMuteSound.contains(getArea().x + inputX, getArea().y + inputY)) {
            Gdx.app.log(TAG, "Handled by buttonUpgrade!");
            return Buttons.MUTE_SOUND;
        }
        return null;
    }
}
