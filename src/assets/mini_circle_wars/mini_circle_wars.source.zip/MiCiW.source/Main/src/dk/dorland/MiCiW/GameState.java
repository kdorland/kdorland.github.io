package dk.dorland.MiCiW;

import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import dk.dorland.MiCiW.Model.Bullet;
import dk.dorland.MiCiW.Model.CircleMonster;
import dk.dorland.MiCiW.Model.CircleTower;

public class GameState {
    public static int SCORE_PER_MONSTER_KILL = 25;
    public static int SCORE_PER_MINUTE = 500;
    public static int SCORE_PER_BUILT_TOWER = 50;

    private Array<CircleTower> towers = new Array<CircleTower>();
    private Array<CircleMonster> monsters = new Array<CircleMonster>();
    private Array<Bullet> bullets = new Array<Bullet>();
    private int energy = 250;
    private int score = 0;
    private float gameTime = 0.0f;
    private boolean gamePaused = false;

    public GameState() {
        towers.add(new CircleTower(new Vector2(5,5), CircleTower.Type.ENERGY, this));
    }

    public void addScore(int value) {
        this.score += value;
    }

    public void addTower(CircleTower tower) {
        towers.add(tower);
        addScore(SCORE_PER_BUILT_TOWER);
    }

    public void addMonster(CircleMonster monster) {
        monsters.add(monster);
    }

    public void addBullet(Bullet bullet) {
        bullets.add(bullet);
    }

    public Array<CircleTower> getTowers() {
        return towers;
    }

    public Array<CircleMonster> getMonsters() {
        return monsters;
    }

    public Array<Bullet> getBullets() {
        return bullets;
    }

    public int energy() {
        return energy;
    }

    public void spendEnergy(int amount) {
        this.energy -= amount;
    }

    public void addEnergy(int amount) {
        this.energy += amount;
        addScore(amount);
    }

    public void removeEnergy(int amount) {
        this.energy -= amount;
    }

    public boolean isGameOver() {
        return towers.size < 1;
    }

    public int getScore() {
        return score;
    }

    public int getSeconds() {
        return (int)Math.ceil(gameTime);
    }

    public void addTimeAsScore() {
        int minutes = (int)Math.ceil(gameTime / 60);
        addScore(minutes * SCORE_PER_MINUTE);
    }

    public void addGameTime(float delta) {
        this.gameTime += delta;
    }

    public void pauseGame() {
        gamePaused = true;
    }

    public void unPauseGame() {
        gamePaused = false;
    }

    public boolean isPaused() {
        return gamePaused;
    }

    public float getGameTime() {
        return gameTime;
    }

}
