package dk.dorland.MiCiW;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.math.Vector2;
import dk.dorland.MiCiW.Model.CircleTower;
import dk.dorland.MiCiW.Utils.DeltaTimer;
import dk.dorland.MiCiW.View.Camera;
import dk.dorland.MiCiW.View.FieldView;
import dk.dorland.MiCiW.View.GameRenderer;
import dk.dorland.MiCiW.View.HUD;

public class GameScreen implements Screen, InputProcessor {
    private static final String TAG = "GameScreen";
    private MiCiWGame game;

    public enum ScreenState {IDLE, DRAGGING, BUILDING, SPAWN_MONSTER}
    private ScreenState screenState = ScreenState.IDLE;

    private GameRenderer gameRenderer;
    private Camera camera;
    private TouchInputHandler touchInputHandler;
    private HUD hud;
    private FieldView fieldView;
    private GameState gameState;
    private GameController gameController;
    private DeltaTimer gameOverTimer;

    // Dragging
    private Vector2 dragStartPosition = new Vector2();
    private Vector2 dragEndPosition = new Vector2();
    private Vector2 dragPosition = new Vector2();

    // Build
    private CircleTower.Type buildTowerType;

    // Select
    private CircleTower selectedTower;

    public GameScreen(MiCiWGame game) {
        this.game = game;
        this.gameState = new GameState();
        this.gameController = new GameController(gameState, this);
        this.camera = new Camera();
        this.gameRenderer = new GameRenderer(this, camera);
        this.touchInputHandler = new TouchInputHandler(this);
        this.hud = new HUD(this);
        this.fieldView = new FieldView();
        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void render(float delta) {
        if (delta > 0.1f) {
            delta = 0.1f;
        }

        if (!gameState.isGameOver()) {
            gameState.addGameTime(delta);
        }

        // If game is over, wait until it's time to show GameOver screen
        if (gameOverTimer != null) {
            gameOverTimer.update(delta);
            if (gameOverTimer.isDone() && Gdx.input.isTouched()) {
                game.setScreen(new GameOverScreen(game, gameState));
            }
        } else if (gameState.isGameOver()) {
            gameOverTimer = new DeltaTimer(4f);
        }

        // Update the game state
        gameController.update(delta);
        gameRenderer.render(delta);
    }

    public void setScreenState(ScreenState state) {
        this.screenState = state;
    }

    public ScreenState getScreenState() {
        return screenState;
    }

    public HUD getHud() {
        return hud;
    }

    public FieldView getFieldView() {
        return fieldView;
    }

    public void selectBuildType(CircleTower.Type type) {
        screenState = ScreenState.BUILDING;
        buildTowerType = type;
    }

    public CircleTower.Type getSelectedBuildType() {
        return buildTowerType;
    }

    public GameState getGameState() {
        return gameState;
    }

    public Camera getCamera() {
        return camera;
    }

    public void setSelectedTower(CircleTower tower) {
        this.selectedTower = tower;
    }

    public CircleTower getSelectedTower() {
        return selectedTower;
    }

    public void createMessage(String msg) {
        gameRenderer.showMessage(msg);
    }

    public GameController getGameController() {
        return gameController;
    }

    public void upgradeSelectedTower() {
        gameController.upgradeTower(selectedTower);
    }


    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {
    }

    @Override
    public boolean keyDown(int keycode) {
        if (keycode == Input.Keys.NUM_0) {
            //screenState = ScreenState.SPAWN_MONSTER;
        } else if (keycode == Input.Keys.P) {
            if (gameState.isPaused()) {
                gameState.unPauseGame();
                createMessage("Game is unpaused.");
            } else {
                gameState.pauseGame();
                createMessage("Game is paused.");
            }
        } else if (keycode == Input.Keys.PAGE_UP) {
            scrolled(-1);
        } else if (keycode == Input.Keys.PAGE_DOWN) {
            scrolled(1);
        } else {
            screenState = ScreenState.IDLE;
        }
        return false;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        if (Input.Buttons.RIGHT == button) {
            setScreenState(ScreenState.IDLE);
        } else if (Input.Buttons.LEFT == button) {
            float touchX = screenX;
            float touchY = screenY;
            touchInputHandler.handleTouch(touchX, touchY);

            if (screenState == ScreenState.DRAGGING) {
                dragStartPosition.x = screenX;
                dragStartPosition.y = screenY;
                camera.startDrag();
            }
        }

        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        if (screenState == ScreenState.DRAGGING) {
            screenState = ScreenState.IDLE;
            dragEndPosition.x = screenX;
            dragEndPosition.y = screenY;
            updateCameraDrag();
        }

        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        if (screenState == ScreenState.DRAGGING) {
            dragEndPosition.x = screenX;
            dragEndPosition.y = screenY;
            updateCameraDrag();
        }
        return false;
    }

    private void updateCameraDrag() {
        dragPosition = dragEndPosition.sub(dragStartPosition);
        dragPosition.y *= -1.0f;
        camera.updateDrag(dragPosition.x, dragPosition.y);
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(int amount) {
        float zoom = 0.2f;
        if (amount < 0) {
            gameRenderer.setZoom(-zoom);
        } else {
            gameRenderer.setZoom(zoom);
        }
        return true;
    }
}
