package dk.dorland.MiCiW.Model;

import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Vector2;
import dk.dorland.MiCiW.Assets;
import dk.dorland.MiCiW.GameState;
import dk.dorland.MiCiW.Utils.DeltaTimer;

public class CircleMonster implements Collidable {
    public static final float CIRCLE_MONSTER_RADIUS = 0.5f;
    public static final float ATTACK_CYCLE_LENGTH = 0.1f;

    private GameState gameState;
    private Vector2 position;
    private Circle bounds;

    private float health = 1.0f;
    private float damagePerCycle = 0.01f;
    private DeltaTimer attackTimer;
    private CircleTower targetTower;
    private Vector2 direction = new Vector2();
    private float velocity;
    private CircleTower.Type targetType;

    public CircleMonster(Vector2 position, GameState gameState, float velocity, CircleTower.Type targetType) {
        this.gameState = gameState;
        this.position = position;
        this.velocity = velocity;
        this.targetType = targetType;
        this.attackTimer = new DeltaTimer(ATTACK_CYCLE_LENGTH);
        this.targetTower = findNearestTower();
        this.bounds = new Circle(position, CIRCLE_MONSTER_RADIUS);
    }

    public void update(float delta) {
        targetTower = findNearestTower();
        attackTimer.update(delta);
        if (targetTower != null) {
            direction.set(targetTower.getPosition());
            direction.sub(position);
            direction.nor();
            direction.scl(velocity * delta);
        }
        updatePosition(direction);
    }

    private void updatePosition(Vector2 vec) {
        position.add(vec);
        bounds.x = position.x;
        bounds.y = position.y;
    }

    public float getX() {
        return position.x;
    }

    public float getY() {
        return position.y;
    }

    public Circle getBounds() {
        return bounds;
    }

    public Vector2 getPosition() {
        return position;
    }

    public boolean attackReady() {
        return attackTimer.isDone();
    }

    public void prepareAttack() {
        attackTimer.reset();
    }

    public float getDamage() {
        return damagePerCycle;
    }

    public void takeDamage(float damage) {
        this.health -= damage;
        Assets.playSound(Assets.soundHit);
    }

    public float getHealth() {
        return health;
    }

    private CircleTower findNearestTower() {
        float distance = 0;
        CircleTower target = null;
        for (CircleTower tower : gameState.getTowers()) {
            if (tower.getType() == targetType || targetType == CircleTower.Type.NONE) {
                if (distance == 0) {
                    distance = tower.getPosition().dst(position);
                    target = tower;
                } else {
                    float newDst = tower.getPosition().dst(position);
                    if (newDst < distance) {
                        distance = newDst;
                        target = tower;
                    }
                }
            }
        }
        return target;
    }

    public CircleTower.Type getTargetType() {
        return targetType;
    }
}
