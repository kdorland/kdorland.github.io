package dk.dorland.MiCiW;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.g2d.BitmapFont;

public class Assets {
    public static BitmapFont font;
    public static BitmapFont fontSmall;
    public static BitmapFont fontLarge;

    public static Sound soundDeath;
    public static Sound soundHit;
    public static Sound soundShot;

    public static float volume = 1.0f;

    public static void loadAssets() {
        // Fonts
        Assets.fontLarge = new BitmapFont(Gdx.files.internal("fonts/04b25_36.fnt"), false);
        Assets.font = new BitmapFont(Gdx.files.internal("fonts/04b25_24.fnt"), false);
        Assets.fontSmall = new BitmapFont(Gdx.files.internal("fonts/04b25_12.fnt"), false);

        Assets.font.setColor(Colors.BLACK);
        Assets.fontSmall.setColor(Colors.BLACK);
        Assets.fontLarge.setColor(Colors.BLACK);

        // Audio
        soundDeath = Gdx.audio.newSound(Gdx.files.internal("audio/death.ogg"));
        soundHit = Gdx.audio.newSound(Gdx.files.internal("audio/hit.ogg"));
        soundShot = Gdx.audio.newSound(Gdx.files.internal("audio/shot.ogg"));
    }

    public static void toggleMuteSound() {
        if (volume != 0.0f) {
            volume = 0.0f;
        } else {
            volume = 1.0f;
        }
    }

    public static void playSound(Sound sound) {
        sound.play(volume);
    }
}
