package dk.dorland.MiCiW;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;

public class MiCiWGame extends Game {
    public static final int SCREEN_WIDTH = 1024;
    public static final int SCREEN_HEIGHT = 600;
    public static final float PIXELS_PER_UNIT = 25f;
    public static final String SAVE_FILE = "miciw.save";

    public void create() {
        Assets.loadAssets();
        setScreen(new TitleScreen(this));
        Gdx.app.setLogLevel(Application.LOG_NONE);
    }
}
