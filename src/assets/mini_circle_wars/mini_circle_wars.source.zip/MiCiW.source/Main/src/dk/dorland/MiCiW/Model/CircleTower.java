package dk.dorland.MiCiW.Model;

import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Vector2;
import dk.dorland.MiCiW.Assets;
import dk.dorland.MiCiW.GameState;
import dk.dorland.MiCiW.Utils.DeltaTimer;

public class CircleTower implements Collidable {
    private static final String TAG = "CircleTower";
    public static final float TOWER_RADIUS = 1f;
    public static final float INFLUENCE_RADIUS = TOWER_RADIUS * 10f;
    public static final float TOWER_DETECT_RADIUS = INFLUENCE_RADIUS;
    public static final int ENERGY_PRODUCTION = 10;
    public static final int UPGRADE_COST = 150;
    public static final int MAX_LEVEL = 3;

    public static final int CANNON_BUILD_COST = 50;
    public static final int ENERGY_BUILD_COST = 100;

    public enum Type {ENERGY, CANNON, NONE}
    public DeltaTimer cycleTimer;
    public DeltaTimer launchTimer;

    private float health = 1.0f;
    private int upgradeLevel = 3;
    private Vector2 position;
    private Circle bounds;
    private Type type;
    private GameState gameState;

    public CircleTower(Vector2 position, Type type, GameState gameState) {
        this.position = position;
        this.type = type;
        this.gameState = gameState;
        this.bounds = new Circle(position, TOWER_RADIUS);
        this.upgradeLevel = 1;
        this.cycleTimer = new DeltaTimer(5f);
        this.launchTimer = new DeltaTimer(2f);
    }

    public void update(float delta) {
        cycleTimer.update(delta);
        launchTimer.update(delta);
    }

    public void fireBullet() {
        //Gdx.app.log(TAG, "fire bullet!");
        Collidable target = findNearestMonster();
        if (target != null) {
            int fireCost = 1;
            if (upgradeLevel == 2) {
                fireCost = 4;
            } else if (upgradeLevel == 3) {
                fireCost = 8;
            }

            // Only fire bullet if enough energy is available.
            if (gameState.energy() >= fireCost) {
                gameState.addBullet(new Bullet(new Vector2(position), findNearestMonster(), upgradeLevel));
                Assets.playSound(Assets.soundShot);
                gameState.removeEnergy(fireCost);
            }
        }
    }

    public boolean bulletReady() {
        return launchTimer.isDone();
    }

    public void prepareBullet() {
        launchTimer.reset();
    }

    public boolean cycleEnded() {
        return cycleTimer.isDone();
    }

    public void resetCycle() {
        cycleTimer.reset();
    }

    private CircleMonster findNearestMonster() {
        float distance = 0;
        CircleMonster target = null;
        for (CircleMonster monster : gameState.getMonsters()) {
            if (distance == 0) {
                distance = monster.getPosition().dst(position);
                target = monster;
            } else {
                float newDst = monster.getPosition().dst(position);
                if (newDst < distance) {
                    distance = newDst;
                    target = monster;
                }
            }
        }

        if (TOWER_DETECT_RADIUS >= distance && distance != 0) {
            return target;
        } else {
            return null;
        }
    }

    public int energyProduced() {
        return ENERGY_PRODUCTION;
    }

    public int energyConsumed() {
        return (int)(ENERGY_PRODUCTION * 0.5f);
    }

    public void setPosition(Vector2 position) {
        this.position = position;
    }

    public float getX() {
        return position.x;
    }

    public float getY() {
        return position.y;
    }

    public Vector2 getPosition() {
        return position;
    }

    public Type getType() {
        return type;
    }

    public Circle getBounds() {
        return bounds;
    }

    public int upgradeLevel() {
        return upgradeLevel;
    }

    public int upgradeCost() {
        if (upgradeLevel == 1) {
            return UPGRADE_COST;
        } else if (upgradeLevel == 2) {
            return UPGRADE_COST * 2;
        } else {
            return UPGRADE_COST * 4;
        }

    }

    public void upgrade() {
        upgradeLevel++;
    }

    public void takeDamage(float damage) {
        this.health -= damage;
    }

    public float getHealth() {
        return health;
    }

}
