package dk.dorland.MiCiW;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import dk.dorland.MiCiW.Utils.DeltaTimer;

public class GameOverScreen implements Screen, InputProcessor {
    private static final String TAG = "GameOverScreen";

    private MiCiWGame game;
    private SpriteBatch spriteBatch;
    private GameState gameState;
    private DeltaTimer timer;
    private float gameTime;
    private int previousHighScore;
    private boolean newHighScore = false;

    public GameOverScreen(MiCiWGame game, GameState gameState) {
        this.game = game;
        this.gameState = gameState;
        this.gameTime = gameState.getGameTime();
        this.spriteBatch = new SpriteBatch();
        this.timer = new DeltaTimer(5f);
        gameState.addTimeAsScore();

        // Save highscore
        Preferences preferences = Gdx.app.getPreferences(MiCiWGame.SAVE_FILE);
        previousHighScore = preferences.getInteger("HIGHSCORE", 0);

        if (previousHighScore < gameState.getScore()) {
            newHighScore = true;
            preferences.putInteger("HIGHSCORE", gameState.getScore());
            preferences.putInteger("HIGHSCORE_SECONDS", gameState.getSeconds());
            preferences.flush();
        }

        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void render(float delta) {
        timer.update(delta);
        Gdx.gl.glClearColor(Colors.BACKGROUND.r, Colors.BACKGROUND.g, Colors.BACKGROUND.b, Colors.BACKGROUND.a);
        Gdx.gl.glEnable(GL10.GL_BLEND);
        Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);

        // Prepare text
        int seconds = (int)gameTime;
        String gameOver = "Game Over";
        String info1 = "You survived for "+seconds+" seconds with a score of "+gameState.getScore()+ ".";
        String info2 = "Your previous best score is "+previousHighScore+".";
        String info3 = "Congratulations on your new highscore!";

        float startY = MiCiWGame.SCREEN_WIDTH * 0.7f;
        float lineHeight = Assets.fontLarge.getLineHeight() * 2.5f;

        spriteBatch.begin();

        Assets.font.setColor(Colors.BLACK);
        Assets.fontLarge.draw(spriteBatch, gameOver,
                MiCiWGame.SCREEN_WIDTH  * 0.5f - Assets.fontLarge.getBounds(gameOver).width * 0.5f,
                startY);

        Assets.font.draw(spriteBatch, info1,
                MiCiWGame.SCREEN_WIDTH  * 0.5f - Assets.font.getBounds(info1).width * 0.5f,
                startY - lineHeight * 2);

        Assets.font.draw(spriteBatch, info2,
                MiCiWGame.SCREEN_WIDTH  * 0.5f - Assets.font.getBounds(info2).width * 0.5f,
                startY - lineHeight * 3);

        if (newHighScore) {
            Assets.font.draw(spriteBatch, info3,
                    MiCiWGame.SCREEN_WIDTH  * 0.5f - Assets.font.getBounds(info3).width * 0.5f,
                    startY - lineHeight * 4);
        }


        spriteBatch.end();

    }

    public void goToTitleScreen() {
        if (timer.isDone()) {
            game.setScreen(new GameScreen(game));
        }
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {
    }

    @Override
    public boolean keyDown(int keycode) {
        goToTitleScreen();
        return true;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        goToTitleScreen();
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(int amount) {
        return false;
    }
}
