package dk.dorland.MiCiW.View;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import dk.dorland.MiCiW.*;
import dk.dorland.MiCiW.Model.Bullet;
import dk.dorland.MiCiW.Model.CircleMonster;
import dk.dorland.MiCiW.Model.CircleTower;
import dk.dorland.MiCiW.Utils.Utils;

public class GameRenderer {
    private static final String TAG = "GameRenderer";
    private static final float TEXT_MARGIN = 5f;
    private static final float SMALL_TEXT_HEIGHT = Assets.fontSmall.getLineHeight();

    private SpriteBatch spriteBatch;
    private ShapeRenderer shapeRenderer;
    private Camera camera;
    private GameScreen gameScreen;
    private float renderX;
    private float renderY;
    private float zoom = 1.0f;

    private CircleTower defaultCannon;
    private CircleTower defaultHarvester;
    private Vector2 tempPosition = new Vector2();

    private Message currentMessage;

    public GameRenderer(GameScreen screen, Camera camera) {
        gameScreen = screen;
        spriteBatch = new SpriteBatch();
        shapeRenderer = new ShapeRenderer();
        this.camera = camera;
        currentMessage = new Message("Welcome to Mini Circle Wars", 5f);

        defaultCannon = new CircleTower(new Vector2(), CircleTower.Type.CANNON, gameScreen.getGameState());
        defaultHarvester = new CircleTower(new Vector2(), CircleTower.Type.ENERGY, gameScreen.getGameState());
    }

    public void render(float delta) {
        Gdx.gl.glClearColor(Colors.BACKGROUND.r, Colors.BACKGROUND.g, Colors.BACKGROUND.b, Colors.BACKGROUND.a);
        Gdx.gl.glEnable(GL10.GL_BLEND);
        Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);

        // Update camera
        camera.setZoomed();
        camera.update();
        OrthographicCamera orthographicCamera = camera.getCamera();
        spriteBatch.setProjectionMatrix(orthographicCamera.combined);
        shapeRenderer.setProjectionMatrix(orthographicCamera.combined);
        renderX = camera.getPosition().x * zoom;
        renderY = camera.getPosition().y * zoom;

        // Render towers
        shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);
        for (CircleTower tower : gameScreen.getGameState().getTowers()) {
            renderTowerOutline(tower);
        }
        for (CircleTower tower : gameScreen.getGameState().getTowers()) {
            renderTower(tower);
        }

        // Render monsters
        for (CircleMonster monster : gameScreen.getGameState().getMonsters()) {
            renderMonster(monster);
        }

        // Render bullets
        for (Bullet bullet : gameScreen.getGameState().getBullets()) {
            renderBullet(bullet);
        }

        // Render HUD
        camera.setUnzoomed();
        shapeRenderer.setProjectionMatrix(orthographicCamera.combined);
        spriteBatch.setProjectionMatrix(orthographicCamera.combined);
        gameScreen.getHud().render(shapeRenderer);
        shapeRenderer.end();

        // Render HUD text
        spriteBatch.begin();
        gameScreen.getHud().render(spriteBatch);

        // Render text message
        renderMessage(delta);
        spriteBatch.end();

        // Render selected tower at cursor
        camera.setZoomed();
        shapeRenderer.setProjectionMatrix(orthographicCamera.combined);
        spriteBatch.setProjectionMatrix(orthographicCamera.combined);
        renderTowerCursor();

        // Debug
        //debugRender();
    }

    public void showMessage(String msg) {
        currentMessage = new Message(msg, 5f);
    }

    private void renderTowerCursor() {
        Gdx.gl.glEnable(GL10.GL_BLEND);
        if (gameScreen.getScreenState() == GameScreen.ScreenState.BUILDING) {
            shapeRenderer.begin(ShapeRenderer.ShapeType.Filled);

            tempPosition = camera.getPositionInWorld(Gdx.input.getX(), Gdx.input.getY());

            if (gameScreen.getSelectedBuildType() == CircleTower.Type.CANNON) {
                defaultCannon.setPosition(tempPosition);
                renderTower(defaultCannon);
            } else {
                defaultHarvester.setPosition(tempPosition);
                renderTower(defaultHarvester);
            }
            shapeRenderer.end();
        }
    }

    private void renderMessage(float delta) {
        if (currentMessage != null) {
            currentMessage.update(delta);
            if (!currentMessage.finished()) {
                Assets.fontSmall.draw(spriteBatch, currentMessage.getMsg(), TEXT_MARGIN, SMALL_TEXT_HEIGHT + TEXT_MARGIN);
            } else {
                currentMessage = null;
            }
        }
    }

    private void renderTowerOutline(CircleTower tower) {
        float radius = CircleTower.INFLUENCE_RADIUS * MiCiWGame.PIXELS_PER_UNIT;
        float x = tower.getX() * MiCiWGame.PIXELS_PER_UNIT;
        float y = tower.getY() * MiCiWGame.PIXELS_PER_UNIT;
        shapeRenderer.setColor(Colors.TOWER_OUTLINE.r, Colors.TOWER_OUTLINE.g, Colors.TOWER_OUTLINE.b, 1f);
        shapeRenderer.circle(renderX + x * zoom, renderY + y * zoom, radius * zoom, 100);
    }

    private void renderTower(CircleTower tower) {
        Color primaryColor = Colors.BLUE;
        if (tower.getType() == CircleTower.Type.CANNON) {
            primaryColor = Colors.RED;
        }
        Color towerColorRed = Utils.interpolateColors(primaryColor, Colors.YELLOW, tower.getHealth());
        Color towerColorBlue = Utils.interpolateColors(primaryColor, Colors.YELLOW, tower.getHealth());
        shapeRenderer.setColor(towerColorBlue);

        float radius = CircleTower.TOWER_RADIUS * MiCiWGame.PIXELS_PER_UNIT;
        float x = tower.getX() * MiCiWGame.PIXELS_PER_UNIT;
        float y = tower.getY() * MiCiWGame.PIXELS_PER_UNIT;

        if (tower.getType() == CircleTower.Type.CANNON) {
            shapeRenderer.setColor(Colors.BLACK.r, Colors.BLACK.g, Colors.BLACK.b, 1f);
            shapeRenderer.circle(renderX + x, renderY + y, radius, 100);
            shapeRenderer.setColor(towerColorRed);

            if (tower.upgradeLevel() == 1) {
                radius *= 0.95f;
            } else if (tower.upgradeLevel() == 2) {
                radius *= 0.85f;
            } else if (tower.upgradeLevel() == 3) {
                radius *= 0.75f;
            }
        }

        shapeRenderer.circle(renderX + x * zoom, renderY + y * zoom, radius * zoom, 100);
    }


    private void renderMonster(CircleMonster monster) {
        float radius = CircleMonster.CIRCLE_MONSTER_RADIUS * MiCiWGame.PIXELS_PER_UNIT;
        float x = monster.getX() * MiCiWGame.PIXELS_PER_UNIT;
        float y = monster.getY() * MiCiWGame.PIXELS_PER_UNIT;

        shapeRenderer.setColor(Colors.YELLOW);
        shapeRenderer.circle(renderX + x * zoom, renderY + y * zoom, radius * zoom, 100);
    }

    private void renderBullet(Bullet bullet) {
        float radius = bullet.getRadius() * MiCiWGame.PIXELS_PER_UNIT;
        float x = bullet.getX() * MiCiWGame.PIXELS_PER_UNIT;
        float y = bullet.getY() * MiCiWGame.PIXELS_PER_UNIT;

        shapeRenderer.setColor(Colors.RED);
        shapeRenderer.circle(renderX + x * zoom, renderY + y * zoom, radius * zoom, 100);
    }

    public void debugRender() {
        Rectangle hud = gameScreen.getHud().getArea();
        Rectangle playground = gameScreen.getFieldView().getArea();
        Rectangle towerArea = gameScreen.getGameController().getTowerArea();
        Rectangle spawnArea = gameScreen.getGameController().getSpawnRectangle();

        // Draw some rectangles
        shapeRenderer.begin(ShapeRenderer.ShapeType.Line);
        shapeRenderer.setColor(Colors.RED);
        shapeRenderer.rect(hud.x, hud.y, hud.width, hud.height);
        shapeRenderer.rect(playground.x, playground.y, playground.width, playground.height);

        // Draw tower area
        shapeRenderer.setColor(Color.ORANGE);
        shapeRenderer.rect(
                renderX + towerArea.x * MiCiWGame.PIXELS_PER_UNIT,
                renderY + towerArea.y * MiCiWGame.PIXELS_PER_UNIT,
                towerArea.width * MiCiWGame.PIXELS_PER_UNIT,
                towerArea.height * MiCiWGame.PIXELS_PER_UNIT);

        shapeRenderer.rect(
                renderX + spawnArea.x * MiCiWGame.PIXELS_PER_UNIT,
                renderY + spawnArea.y * MiCiWGame.PIXELS_PER_UNIT,
                spawnArea.width * MiCiWGame.PIXELS_PER_UNIT,
                spawnArea.height * MiCiWGame.PIXELS_PER_UNIT);

        shapeRenderer.end();
    }

    public void setZoom(float value) {
        float newZoom = camera.getCamera().zoom * (1 + value);
        if (newZoom < 0.50f || newZoom > 12f) {
            return;
        }
        //Gdx.app.log(TAG, "newZoom: "+newZoom);
        camera.setZoomFactor(newZoom);
    }
}
