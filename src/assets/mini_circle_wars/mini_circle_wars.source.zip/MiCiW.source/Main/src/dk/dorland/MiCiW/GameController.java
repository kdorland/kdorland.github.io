package dk.dorland.MiCiW;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import dk.dorland.MiCiW.Model.Bullet;
import dk.dorland.MiCiW.Model.CircleMonster;
import dk.dorland.MiCiW.Model.CircleTower;
import dk.dorland.MiCiW.Model.Collidable;
import dk.dorland.MiCiW.Utils.DeltaTimer;
import dk.dorland.MiCiW.Utils.Utils;

public class GameController {
    private static final String TAG = "GameController";
    private final int SPAWN_DISTANCE = 25;
    private final int WAVE_TIME = 30;
    private final int SPAWN_INTERVAL = 15;

    private GameState gameState;
    private GameScreen gameScreen;
    private Rectangle towerArea = new Rectangle();
    private Rectangle spawnRectangle = new Rectangle();
    private Vector2 dir = new Vector2();
    private DeltaTimer spawnTimer;
    private float stateTime = 0.0f;

    public GameController(GameState gameState, GameScreen gameScreen) {
        this.gameState = gameState;
        this.gameScreen = gameScreen;
        this.spawnTimer = new DeltaTimer(SPAWN_INTERVAL);
    }

    public void update(float delta) {
        stateTime += delta;

        // Update area bounded by towers
        updateTowerArea();
        spawnRectangle.x = towerArea.x - SPAWN_DISTANCE;
        spawnRectangle.y = towerArea.y - SPAWN_DISTANCE;
        spawnRectangle.width = towerArea.width + SPAWN_DISTANCE * 2;
        spawnRectangle.height = towerArea.height + SPAWN_DISTANCE * 2;

        if (gameState.isPaused()) {
            return;
        }

        // Update towers
        for (CircleTower tower : gameState.getTowers()) {
            tower.update(delta);

            if (tower.getType() == CircleTower.Type.CANNON && tower.bulletReady()) {
                tower.fireBullet();
                tower.prepareBullet();
            }

            if (tower.cycleEnded()) {
                tower.resetCycle();
                if (tower.getType() == CircleTower.Type.ENERGY) {
                    gameState.addEnergy(tower.energyProduced());
                }
            }
        }

        // Update monsters
        for (CircleMonster monster : gameState.getMonsters()) {
            monster.update(delta);
            monsterAttackTowers(monster);
            preventCollisionWithOthers(monster);
            if (monster.getHealth() <= 0.0f) {
                gameState.getMonsters().removeValue(monster, true);
                gameState.addScore(GameState.SCORE_PER_MONSTER_KILL);
            }
        }

        // Update bullets
        for (Bullet bullet : gameState.getBullets()) {
            bullet.update(delta);
            bulletCollisionHandling(bullet);
            if (bullet.timeToDie()) {
                gameState.getBullets().removeValue(bullet, true);
            }
        }

        // Spawn more monsters
        spawnMoreMonsters(delta);
    }

    public void upgradeTower(CircleTower tower) {
        if (tower.upgradeCost() > gameState.energy()) {
            int difference = tower.upgradeCost() - gameState.energy();
            gameScreen.createMessage("You need " + difference + " more energy to upgrade.");
            return;
        }

        if (tower.upgradeLevel() == 3) {
            gameScreen.createMessage("Tower is already at max level.");
            return;
        }

        tower.upgrade();
    }

    private void spawnMoreMonsters(float delta) {
        spawnTimer.update(delta);
        if (spawnTimer.isDone()) {
            spawnTimer.reset();

            float velocity = 0.75f;
            int wave = (int)(stateTime / WAVE_TIME) + 1;
            Gdx.app.log(TAG, "Wave: "+wave);
            int size = 1;
            CircleTower.Type targetType = CircleTower.Type.NONE;

            if (wave > 3) {
                size = 2;
                velocity = 1f;
            }

            if (wave > 5) {
                size = 3;
                velocity = 1.5f;
            }

            if (wave > 8) {
                size = size + (wave - 8) + 3;
                velocity = 2.0f;
            }

            if (wave > 20) {
                size = size + ((wave - 100) * (wave - 100));
                velocity = 2.5f;
                targetType = CircleTower.Type.ENERGY;
            }

            // Armageddon
            if (wave > 50) {
                size = size + ((wave - 100) * (wave - 100) * (wave - 100)) ;
                velocity = 10f;
                targetType = CircleTower.Type.ENERGY;
            }

            for (int i = 0; i < size; i++) {
                if (wave > 10) {
                    int lucky = (int)(Math.random() * 4f);
                    if (lucky == 1) {
                        targetType = CircleTower.Type.ENERGY;
                    } else {
                        targetType = CircleTower.Type.NONE;
                    }
                }

                spawnRandomMonster(velocity, targetType);
            }
        }
    }

    private void monsterAttackTowers(CircleMonster monster) {
        if (monster.attackReady()) {
            for (CircleTower tower : gameState.getTowers()) {
                if (monster.getBounds().overlaps(tower.getBounds())) {
                    tower.takeDamage(monster.getDamage());
                    monster.prepareAttack();
                    if (tower.getHealth() <= 0.0f) {
                        gameState.getTowers().removeValue(tower, true);
                        Assets.playSound(Assets.soundDeath);
                    }
                }
            }
        }
    }

    private void updateTowerArea() {
        if (gameState.getTowers().size == 0) {
            return;
        }
        Circle bounds = gameState.getTowers().get(0).getBounds();
        towerArea.x = bounds.x - bounds.radius;
        towerArea.y = bounds.y - bounds.radius;
        towerArea.width = bounds.radius;
        towerArea.height = bounds.radius;

        for (CircleTower tower : gameState.getTowers()) {
            bounds = tower.getBounds();
            float xLeft = bounds.x - bounds.radius;
            float xRight = bounds.x + bounds.radius;
            float yTop = bounds.y + bounds.radius;
            float yBottom = bounds.y - bounds.radius;

            if (xLeft < towerArea.x) {
                towerArea.width += towerArea.x - xLeft;
                towerArea.x = xLeft;
            }

            if (yBottom < towerArea.y) {
                towerArea.height += towerArea.y - yBottom;
                towerArea.y = yBottom;
            }

            if (xRight > towerArea.x + towerArea.width) {
                towerArea.width = xRight - towerArea.x;
            }

            if (yTop > towerArea.y + towerArea.height) {
                towerArea.height = yTop - towerArea.y;
            }
        }
    }

    private void bulletCollisionHandling(Bullet bullet) {
        // Collision with monsters
        for (CircleMonster monster : gameState.getMonsters()) {
            if (monster.getBounds().overlaps(bullet.getBounds())) {
                monster.takeDamage(bullet.getDamage());
                if (monster.getHealth() <= 0.0f) {
                    gameState.getMonsters().removeValue(monster, true);
                }
                gameState.getBullets().removeValue(bullet, true);
            }
        }
    }

    public void preventCollisionWithOthers(CircleMonster monster) {

        // Collision with towers
        for (CircleTower tower : gameState.getTowers()) {
            handleCollision(monster, tower);
        }

        // Collision with other monsters
        /*  this clearly doesn't work very well :)
        for (int i = 0; i < gameState.getMonsters().size; i++) {
            CircleMonster other = gameState.getMonsters().get(i);
            handleCollision(monster, other);
        }
        */
    }

    private void handleCollision(Collidable me, Collidable other) {
        if (other.getBounds().overlaps(me.getBounds())) {
            // The distance from the border of teh monster and the tower
            float overlapDistance = other.getPosition().dst(me.getPosition())
                    - other.getBounds().radius - me.getBounds().radius;
            overlapDistance = Math.abs(overlapDistance);

            // Push monster back so it only touches tower
            dir.set(me.getPosition());
            dir.sub(other.getPosition());
            dir.nor();
            dir.scl(overlapDistance);
            me.getPosition().add(dir);
        }
    }

    public boolean collisionWithAnotherTower(CircleTower tower) {
        for (CircleTower another : gameState.getTowers()) {
            if (another.getBounds().overlaps(tower.getBounds())) {
                return true;
            }
        }
        return false;
    }

    public boolean isTowerInTowerArea(CircleTower tower) {
        for (CircleTower another : gameState.getTowers()) {
            Circle bounds = new Circle(another.getPosition(), another.getBounds().radius);
            bounds.radius = CircleTower.INFLUENCE_RADIUS;
            if (bounds.contains(tower.getBounds())) {
                return true;
            }
        }
        return false;
    }

    public void spawnRandomMonster(float velocity, CircleTower.Type targetType) {
        float x = 0, y = 0;
        int side = (int) Utils.random(1,4);
        boolean top = false, left = false, bottom = false, right = false;
        switch (side) {
            case 1: top = true; break;
            case 2: left = true; break;
            case 3: bottom = true; break;
            case 4: right = true; break;
        }

        if (top) {
            x = Utils.random(spawnRectangle.x,
                             spawnRectangle.x + spawnRectangle.width);
            y = spawnRectangle.getY() + spawnRectangle.height;
        } else if (bottom) {
            x = Utils.random(spawnRectangle.x,
                             spawnRectangle.x + spawnRectangle.width);
            y = spawnRectangle.getY();
        } else if (right) {
            x = spawnRectangle.getX();
            y = Utils.random(spawnRectangle.y,
                             spawnRectangle.y + spawnRectangle.height);
        } else if (left) {
            x = spawnRectangle.getX() + spawnRectangle.width;
            y = Utils.random(spawnRectangle.y,
                             spawnRectangle.y + spawnRectangle.height);
        }

        gameState.addMonster(new CircleMonster(new Vector2(x,y), gameState, velocity, targetType));
    }

    public Rectangle getTowerArea() {
        return towerArea;
    }

    public Rectangle getSpawnRectangle() {
        return spawnRectangle;
    }

}
