package dk.dorland.MiCiW.Utils;

public class DeltaTimer {
    private float stateTime;
    private float duration;

    public DeltaTimer(float duration) {
        this.duration = duration;
        this.stateTime = 0.0f;
    }

    public void update(float delta) {
        stateTime += delta;
    }

    public void reset() {
        stateTime = 0.0f;
    }

    public boolean isDone() {
        return stateTime > duration;
    }

    public float getStateTime() {
        return stateTime;
    }

    public void setDuration(float duration) {
        this.duration = duration;
    }

}
