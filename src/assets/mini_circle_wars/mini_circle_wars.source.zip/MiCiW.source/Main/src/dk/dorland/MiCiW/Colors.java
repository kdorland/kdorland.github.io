package dk.dorland.MiCiW;

import com.badlogic.gdx.graphics.Color;

public class Colors {

    public static final Color RED = Color.RED;
    public static final Color RED_LIGHT = Color.valueOf("ffc7c7");

    public static final Color YELLOW = Color.valueOf("ed9511");
    public static final Color BLUE = Color.valueOf("1970d4");
    public static final Color BLUE_LIGHT = Color.valueOf("a9bfd9");

    public static final Color BLACK = Color.valueOf("041830");//Color.BLACK;
    public static final Color GREEN = Color.GREEN;

    public static final Color HUD_BACKGROUND = Color.valueOf("88bdbd");
    public static final Color BACKGROUND = Color.valueOf("d5e6e2");

    public static final Color TOWER_OUTLINE = Color.valueOf("bddbd2");
}
