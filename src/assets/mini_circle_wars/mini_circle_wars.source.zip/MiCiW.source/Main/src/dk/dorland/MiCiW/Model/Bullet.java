package dk.dorland.MiCiW.Model;

import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Vector2;
import dk.dorland.MiCiW.Utils.DeltaTimer;

public class Bullet {
    private static final String TAG = "Bullet";

    public static final float RADIUS = 0.1f;

    private Circle bounds = new Circle();
    private Vector2 position = new Vector2();
    private Vector2 direction = new Vector2();
    private float damage;
    private float velocity;
    private DeltaTimer stillAliveTimer;
    private int upgradeLevel;

    public Bullet(Vector2 position, Collidable target, int upgradeLevel) {
        this.position = position;
        this.upgradeLevel = upgradeLevel;
        stillAliveTimer = new DeltaTimer(3f);

        if (upgradeLevel == 1) {
            damage = 0.1f;
            velocity = 3f;
            stillAliveTimer.setDuration(3f);
        } else if (upgradeLevel == 2) {
            damage = 0.4f;
            velocity = 5f;
            stillAliveTimer.setDuration(4f);
        } else {
            damage = 1f;
            velocity = 7f;
            stillAliveTimer.setDuration(5f);
        }

        bounds.x = position.x;
        bounds.y = position.y;
        setDirection(target);

    }

    public void update(float delta) {
        stillAliveTimer.update(delta);
        direction.nor();
        direction.scl(velocity * delta);
        updatePosition(direction);
    }

    public boolean timeToDie() {
        return stillAliveTimer.isDone();
    }

    private void setDirection(Collidable target) {
        direction.set(target.getPosition());
        direction.sub(position);
    }

    private void updatePosition(Vector2 vec) {
        position.add(vec);
        bounds.x = position.x;
        bounds.y = position.y;
    }

    public float getX() {
        return position.x;
    }

    public float getY() {
        return position.y;
    }

    public Circle getBounds() {
        return bounds;
    }

    public float getDamage() {
        return damage;
    }

    public float getRadius() {
        return RADIUS * upgradeLevel;
    }
}
