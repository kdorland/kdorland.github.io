package dk.dorland.MiCiW;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL10;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import dk.dorland.MiCiW.Utils.DeltaTimer;

public class TitleScreen implements Screen, InputProcessor {
    private static final String TAG = "TitleScreen";

    private MiCiWGame game;
    private SpriteBatch spriteBatch;

    public TitleScreen(MiCiWGame game) {
        this.game = game;
        this.spriteBatch = new SpriteBatch();
        Gdx.input.setInputProcessor(this);
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(Colors.BACKGROUND.r, Colors.BACKGROUND.g, Colors.BACKGROUND.b, Colors.BACKGROUND.a);
        Gdx.gl.glEnable(GL10.GL_BLEND);
        Gdx.gl.glClear(GL10.GL_COLOR_BUFFER_BIT);

        // Get previous highscore and time
        Preferences preferences = Gdx.app.getPreferences(MiCiWGame.SAVE_FILE);
        int highscore = preferences.getInteger("HIGHSCORE", 0);
        int seconds = preferences.getInteger("HIGHSCORE_SECONDS", 0);

        // Prepare text
        String title = "Mini Circle Wars";
        String info1 = "Highscore: "+highscore+" points in "+seconds+" seconds.";
        String info2 = "Press any key to start";

        float startY = MiCiWGame.SCREEN_HEIGHT * 0.8f;
        float lineHeight = Assets.font.getLineHeight() * 2.5f;

        spriteBatch.begin();

        Assets.font.setColor(Colors.BLACK);
        Assets.fontLarge.draw(spriteBatch, title,
                MiCiWGame.SCREEN_WIDTH  * 0.5f - Assets.fontLarge.getBounds(title).width * 0.5f,
                startY);

        Assets.font.draw(spriteBatch, info1,
                MiCiWGame.SCREEN_WIDTH  * 0.5f - Assets.font.getBounds(info1).width * 0.5f,
                startY - lineHeight * 2);

        Assets.font.draw(spriteBatch, info2,
                MiCiWGame.SCREEN_WIDTH  * 0.5f - Assets.font.getBounds(info2).width * 0.5f,
                startY - lineHeight * 4);

        spriteBatch.end();

    }

    public void gotoGameScreen() {
        game.setScreen(new GameScreen(game));
    }

    @Override
    public void resize(int width, int height) {
    }

    @Override
    public void show() {
    }

    @Override
    public void hide() {
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {
    }

    @Override
    public void dispose() {
    }

    @Override
    public boolean keyDown(int keycode) {
        gotoGameScreen();
        return true;
    }

    @Override
    public boolean keyUp(int keycode) {
        return false;
    }

    @Override
    public boolean keyTyped(char character) {
        return false;
    }

    @Override
    public boolean touchDown(int screenX, int screenY, int pointer, int button) {
        gotoGameScreen();
        return true;
    }

    @Override
    public boolean touchUp(int screenX, int screenY, int pointer, int button) {
        return false;
    }

    @Override
    public boolean touchDragged(int screenX, int screenY, int pointer) {
        return false;
    }

    @Override
    public boolean mouseMoved(int screenX, int screenY) {
        return false;
    }

    @Override
    public boolean scrolled(int amount) {
        return false;
    }
}
