package dk.dorland.MiCiW.View;

import com.badlogic.gdx.math.Rectangle;
import dk.dorland.MiCiW.MiCiWGame;

public class FieldView {
    private Rectangle fieldViewArea = new Rectangle();

    public FieldView() {
        fieldViewArea.height = MiCiWGame.SCREEN_HEIGHT;
        fieldViewArea.width = MiCiWGame.SCREEN_WIDTH - HUD.HUD_WIDTH;
        fieldViewArea.x = 0;
        fieldViewArea.y = 0;
    }

    public Rectangle getArea() {
        return fieldViewArea;
    }

}
