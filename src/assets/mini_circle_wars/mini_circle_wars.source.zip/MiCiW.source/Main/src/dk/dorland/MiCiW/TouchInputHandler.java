package dk.dorland.MiCiW;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.math.Vector2;
import dk.dorland.MiCiW.Model.CircleMonster;
import dk.dorland.MiCiW.Model.CircleTower;
import dk.dorland.MiCiW.View.HUD;

public class TouchInputHandler {
    public static final String TAG = "TouchInputHandler";
    private GameScreen gameScreen;

    public TouchInputHandler(GameScreen gameScreen) {
        this.gameScreen = gameScreen;
    }

    public void handleTouch(float screenX, float screenY) {
        if (gameScreen.getGameState().isGameOver() || gameScreen.getGameState().isPaused()) {
            if (gameScreen.getGameState().isPaused()) {
                gameScreen.createMessage("Game is paused. Unpause with 'p'.");
            }
            return;
        }

        if (gameScreen.getHud().getArea().contains(screenX, screenY)) {
            hudTouchHandler(screenX - gameScreen.getHud().getArea().x, MiCiWGame.SCREEN_HEIGHT - screenY);
        } else if (gameScreen.getFieldView().getArea().contains(screenX, screenY)) {
            Vector2 position = gameScreen.getCamera().getPositionInWorld(screenX, screenY);
            playfieldTouchHandler(position.x, position.y);
        }
    }

    private void hudTouchHandler(float x, float y) {
        Gdx.app.log(TAG, "Touch in the HUD! "+"("+x+","+y+")");
        HUD.Buttons button = gameScreen.getHud().handleInput(x, y);
        if (button == HUD.Buttons.HARVESTER) {
            gameScreen.selectBuildType(CircleTower.Type.ENERGY);
        } else if (button == HUD.Buttons.CANNON) {
            gameScreen.selectBuildType(CircleTower.Type.CANNON);
        } else if (button == HUD.Buttons.UPGRADE) {
            gameScreen.upgradeSelectedTower();
        } else if (button == HUD.Buttons.MUTE_SOUND) {
            Assets.toggleMuteSound();
        }
    }

    private void playfieldTouchHandler(float x, float y) {
        Gdx.app.log(TAG, "Touch in the playfield! "+"("+x+","+y+")");

        if (gameScreen.getScreenState() == GameScreen.ScreenState.SPAWN_MONSTER) {
            CircleMonster monster = new CircleMonster(new Vector2(x, y), gameScreen.getGameState(), 3f, CircleTower.Type.NONE);
            gameScreen.getGameState().addMonster(monster);
            gameScreen.getGameController().spawnRandomMonster(3, CircleTower.Type.NONE);

        } else if (gameScreen.getScreenState() == GameScreen.ScreenState.BUILDING) {
           buildTower(x, y);

        } else {
            gameScreen.setScreenState(GameScreen.ScreenState.DRAGGING);
            gameScreen.setSelectedTower(null);
            for (CircleTower tower : gameScreen.getGameState().getTowers()) {
                if (tower.getBounds().contains(x, y)) {
                    Gdx.app.log(TAG, "Clicked on tower with type: "+tower.getType());
                    gameScreen.setSelectedTower(tower);
                }
            }
        }
    }

    private void buildTower(float x, float y) {
        GameState gameState = gameScreen.getGameState();
        CircleTower.Type type = gameScreen.getSelectedBuildType();
        int cost = CircleTower.ENERGY_BUILD_COST;
        if (type == CircleTower.Type.CANNON)  {
            cost = CircleTower.CANNON_BUILD_COST;
        }
        // Check energy cost
        if (gameState.energy() < cost) {
            gameScreen.createMessage("Not enough energy! Need "+cost +" to build.");
            return;
        }
        CircleTower newTower = new CircleTower(new Vector2(x, y), gameScreen.getSelectedBuildType(), gameScreen.getGameState());

        // Check collision with other towers
        if (gameScreen.getGameController().collisionWithAnotherTower(newTower)) {
            gameScreen.createMessage("Cannot build on top of other towers!");
            return;
        }

        // Check that tower is built inside tower area
        if (!gameScreen.getGameController().isTowerInTowerArea(newTower)) {
            gameScreen.createMessage("Tower needs to be built inside the influence area of another tower.");
            return;
        }

        gameState.addTower(newTower);
        gameState.spendEnergy(cost);

    }

}
