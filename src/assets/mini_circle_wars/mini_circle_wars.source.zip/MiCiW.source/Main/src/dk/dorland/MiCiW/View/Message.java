package dk.dorland.MiCiW.View;

import dk.dorland.MiCiW.Utils.DeltaTimer;

public class Message {
    private DeltaTimer timer;
    private String msg;

    public Message(String msg, float duration) {
        this.msg = msg;
        this.timer = new DeltaTimer(duration);
    }

    public void update(float delta) {
        timer.update(delta);
    }

    public boolean finished() {
        return timer.isDone();
    }

    public String getMsg() {
        return msg;
    }
}
