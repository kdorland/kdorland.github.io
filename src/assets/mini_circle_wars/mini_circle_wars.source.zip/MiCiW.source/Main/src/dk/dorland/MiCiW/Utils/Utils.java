package dk.dorland.MiCiW.Utils;

import com.badlogic.gdx.graphics.Color;

public class Utils {

    private static Color result = new Color();

    public static float random(float min, float max) {
        return min + (float)(Math.random() * ((max - min) + 1.0f));
    }

    public static Color interpolateColors(Color color1, Color color2, float value) {
        result.r = color1.r * value + color2.r * (1 - value);
        result.g = color1.g * value + color2.g * (1 - value);
        result.b = color1.b * value + color2.b * (1 - value);
        result.a = 1.0f;
        return result;
    }
}
