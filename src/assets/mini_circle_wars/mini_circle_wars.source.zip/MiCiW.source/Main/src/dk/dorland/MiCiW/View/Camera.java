package dk.dorland.MiCiW.View;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import dk.dorland.MiCiW.MiCiWGame;

public class Camera {
    private static final String TAG = "Camera";

    private OrthographicCamera camera;
    private Vector2 cameraPosition = new Vector2();
    private Vector2 cameraInitDragPosition = new Vector2();
    private float zoom = 1.0f;

    public Camera() {
        camera = new OrthographicCamera();
        camera.setToOrtho(false);
        cameraPosition.x = MiCiWGame.SCREEN_WIDTH * 0.5f;
        cameraPosition.y = MiCiWGame.SCREEN_HEIGHT * 0.5f;
    }

    public OrthographicCamera getCamera() {
        return camera;
    }

    public void update() {
        camera.update();
    }

    public void startDrag() {
        cameraInitDragPosition.x = cameraPosition.x;
        cameraInitDragPosition.y = cameraPosition.y;
    }

    public void updateDrag(float x, float y) {
        cameraPosition.x = cameraInitDragPosition.x + x * zoom;
        cameraPosition.y = cameraInitDragPosition.y + y * zoom;
    }

    public Vector2 getPosition() {
        return cameraPosition;
    }

    public Vector2 getPositionInWorld(float x, float y) {
        Vector3 spritePosition = new Vector3();
        //setZoomed();
        camera.unproject(spritePosition.set(x, y, 0));

        float posX = (spritePosition.x - cameraPosition.x) / MiCiWGame.PIXELS_PER_UNIT;
        float posY = (spritePosition.y - cameraPosition.y) / MiCiWGame.PIXELS_PER_UNIT;

        return new Vector2(posX, posY);
    }

    public void setZoomFactor(float value) {
        zoom = value;
    }

    public void setUnzoomed() {
        camera.zoom = 1.0f;
        camera.update();
    }

    public void setZoomed() {
        camera.zoom = zoom;
        camera.update();
    }


}
