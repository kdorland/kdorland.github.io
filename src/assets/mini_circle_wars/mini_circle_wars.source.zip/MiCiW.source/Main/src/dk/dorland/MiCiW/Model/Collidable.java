package dk.dorland.MiCiW.Model;

import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Vector2;

public interface Collidable {
    public Circle getBounds();
    public Vector2 getPosition();
}
